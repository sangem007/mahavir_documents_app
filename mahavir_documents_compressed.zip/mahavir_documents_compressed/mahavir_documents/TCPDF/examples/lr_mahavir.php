<?php

require_once('tcpdf_include.php');
$consignee_name=$_POST['consignee_name'];
$consignee_phone=$_POST['consignee_phone'];
$consignee_address=$_POST['consignee_address'];
$consigner_name=$_POST['consigner_name'];
$consigner_phone=$_POST['consigner_phone'];
$consigner_address=$_POST['consigner_address'];

$loading="UNLOADING WILL BE DONE BY ";
$loading= $loading.$_POST['loading'];

//$by_party=$_POST['by_party'];
$vehicle_no=$_POST['vehicle_no'];
$from_loc=$_POST['from_loc'];
$to_loc=$_POST['to_loc'];
$date_of_shifting=$_POST['date_of_shifting'];
$cosignment_note=$_POST['cosignment_note'];
$total_packages=$_POST['total_packages'];
$amount=$_POST['amount'];
$gst_charges=$_POST['gst_charges'];
$advance=$_POST['advance'];
$balance=$_POST['balance'];




$pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);


/*
$cust_name=$_POST['cust_name'];
$date=$_POST['date'];
$lr=$_POST['lr'];
$from=$_POST['from'];
$to=$_POST['to'];
$exec_name=$_POST['exec_name'];
*/

/*
$pdf->SetCreator('Mahavir Packers');
$pdf->SetAuthor('Mahavir Packers Pvt Ltd');
$pdf->SetTitle('Article List');
$pdf->SetSubject('Article List');
$pdf->SetKeywords('TCPDF, PDF, example, test, guide');
*/


header('Content-Type: application/pdf');
header('Content-Disposition: attachment; filename="lorry_report.pdf"');
$pdf->SetHeaderData('logo.png', 10, 'Mahavir Packers Pvt Ltd', PDF_HEADER_STRING);

$pdf->setHeaderFont(Array(PDF_FONT_NAME_MAIN, '', PDF_FONT_SIZE_MAIN));
$pdf->setFooterFont(Array(PDF_FONT_NAME_DATA, '', PDF_FONT_SIZE_DATA));

$pdf->SetDefaultMonospacedFont(PDF_FONT_MONOSPACED);
$pdf->setPrintHeader(false);


//$pdf->SetAutoPageBreak(TRUE, PDF_MARGIN_BOTTOM);

$pdf->setImageScale(PDF_IMAGE_SCALE_RATIO);

// set some language-dependent strings (optional)
if (@file_exists(dirname(__FILE__).'/lang/eng.php')) {
	require_once(dirname(__FILE__).'/lang/eng.php');
	$pdf->setLanguageArray($l);
}

// ---------------------------------------------------------

$pdf->SetFont('dejavusans', '', 10);

$pdf->AddPage();

$html = '<div><a href="https://www.shreemahavirpackers.in"><img align=center src="images/mahavir_white.png" width="675" height="100" ></a></div>';// output the HTML content

$pdf->writeHTML($html, true, false, true, false, '');

$html = '
<table bgcolor="#F2F2F2" border="1" width="675" cellspacing="4" cellpadding="3">


<tr>
<td bgcolor="#A8A8A8" width="180">AT OWNER\'S RISK	</td>
<td bgcolor="#A8A8A8" width="263">Consignee Copy	</td>
<td bgcolor="#A8A8A8" width="80">Vehicle No </td>
<td bgcolor="#A8A8A8" width="120"><b>'.$vehicle_no.'</b></td>
</tr>

<tr >
<td colspan="2" style="text-align:center"><b>'.$loading.'</b></td>
<td ><small>Consignment notes:</small></td>
<td ><b>'.$cosignment_note.'</b></td>
</tr>

<tr>
<td>Consignee\'s Phone:	</td>
<td><b>'.$consignee_phone.'</b></td>
<td >DATE</td>
<td ><b>'.$date_of_shifting.'</b></td>
</tr>

<tr>
<td>Consignee\'s Name:	</td>
<td><b>'.$consignee_name.'</b></td>
<td >From</td>
<td ><b>'.$from_loc.'</b></td>
</tr>

<tr>
<td rowspan="3">Consignee\'s Address:	</td>
<td rowspan="3"><b>'.$consignee_address.'</b></td>
<td >To</td>
<td ><b>'.$to_loc.'</b></td>
</tr>

<tr>
<td style="border:none;"></td>
<td ></td>

</tr>

<tr>
<td ></td>
<td ></td>

</tr>
<tr>
<td>Consigner\'s Phone:	</td>
<td ><b>'.$consigner_phone.'</b></td>
<td ></td>
<td ></td>
</tr>

<tr>
<td>Consigner\'s Name:	</td>
<td><b>'.$consigner_name.'</b></td>
<td></td>
<td></td>
</tr>

<tr>
<td rowspan="3">Consigner\'s Address:	</td>
<td rowspan="3" ><b>'.$consigner_address.'</b></td>
<td></td>
<td></td>
</tr>
<tr>
<td ></td>
<td ></td>

</tr>
<tr>
<td ></td>
<td ></td>

</tr>

</table>';


$html .='<br><br>';




$html .='<table bgcolor="#F2F2F2" border="1" width="675" cellspacing="4" cellpadding="3">

<tr>
<td bgcolor="#A8A8A8" style="text-align:center;">Packages</td>
<td bgcolor="#A8A8A8">Descriptions(Said To Contain)</td>
<td bgcolor="#A8A8A8" style="text-align:center;">Weight</td>
<td bgcolor="#A8A8A8" style="text-align:center;">Rate</td>
<td bgcolor="#A8A8A8" style="text-align:center;">AMOUNT TO PAY / PAID</td>

</tr>



<tr>
<td></td>
<td></td>
<td width="62" bgcolor="#A8A8A8">Actual</td>
<td width="62" bgcolor="#A8A8A8">Charge</td>

<td></td>
<td width="135">RS</td>

</tr>


<tr>
<td style="text-align:center;"><b>As per list</b></td>
<td ><b>Household goods</b></td>
<td></td>
<td></td>

<td ><b>AMOUNT</b></td>
<td></td>
</tr>

<tr>
<td style="text-align:center;"><b>'.$total_packages.'</b></td>
<td text-align="center"><b>USED & OLD</b></td>
<td></td>
<td></td>
<td >ST.CHARGES</td>
<td></td>
</tr>

<tr>
<td ></td>
<td ><b>NOTE: not for sale</b></td>
<td></td>
<td></td>
<td >TOTAL</td>
<td></td>
</tr>

<tr>
<td ></td>
<td ></td>
<td></td>
<td></td>
<td >ADVANCED</td>
<td></td>
</tr>

<tr>
<td ></td>
<td ></td>
<td></td>
<td></td>
<td >BALANCE</td>
<td></td>
</tr>










</table>';

$html .='<br><div align="center"><a href="https://www.shreemahavirpackers.in" color="#800000" style="text-decoration:none;">© 2020 Shree Mahavir Packers Pvt Ltd Copyright - All Rights Reserved</a></div>';
// output the HTML content
$pdf->writeHTML($html, true, false, true, false, '');

// Print some HTML Cells

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
// Print all HTML colors

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

// test custom bullet points for list

$file_name = preg_replace('/\s+/', '_', $consignee_name);
$file_name=$file_name.'_lr.pdf';


ob_end_clean();

exit($pdf->Output($file_name, 'D'));

//Close and output PDF document
//$pdf->Output('example_006.pdf', 'I');

//============================================================+
// END OF FILE
//============================================================+
