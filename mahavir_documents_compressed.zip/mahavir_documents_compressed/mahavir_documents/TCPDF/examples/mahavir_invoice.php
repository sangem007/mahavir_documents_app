<?php

require_once('tcpdf_include.php');


$cust_name=$_POST['cust_name'];
$cust_phone=$_POST['cust_phone'];
$cust_address=$_POST['cust_address'];
$client_gst=$_POST['client_gst'];
$bill_no=$_POST['bill_no'];
$shift_date=$_POST['shift_date'];
$from_loc=$_POST['from_loc'];
$to_loc=$_POST['to_loc'];
$details_1=$_POST['details_1'];
$amount_1=$_POST['amount_1'];

$c_gst=$_POST['c_gst'];
$s_gst=$_POST['s_gst'];
$total_amount=$_POST['total_amount'];
$lr_no=$_POST['lr_no'];
$rate_c_gst=$_POST['rate_c_gst'];
$rate_s_gst=$_POST['rate_s_gst'];



$pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);


header('Content-Type: application/pdf');
header('Content-Disposition: attachment; filename="invoice.pdf"');
$pdf->SetHeaderData('logo.png', 10, 'Mahavir Packers Pvt Ltd', PDF_HEADER_STRING);

$pdf->setHeaderFont(Array(PDF_FONT_NAME_MAIN, '', PDF_FONT_SIZE_MAIN));
$pdf->setFooterFont(Array(PDF_FONT_NAME_DATA, '', PDF_FONT_SIZE_DATA));

$pdf->SetDefaultMonospacedFont(PDF_FONT_MONOSPACED);
$pdf->setPrintHeader(false);


//$pdf->SetAutoPageBreak(TRUE, PDF_MARGIN_BOTTOM);

$pdf->setImageScale(PDF_IMAGE_SCALE_RATIO);

// set some language-dependent strings (optional)
if (@file_exists(dirname(__FILE__).'/lang/eng.php')) {
	require_once(dirname(__FILE__).'/lang/eng.php');
	$pdf->setLanguageArray($l);
}

// ---------------------------------------------------------

$pdf->SetFont('dejavusans', '', 10);

$pdf->AddPage();

$html = '<div><a href="https://www.shreemahavirpackers.in"><img align=center src="images/mahavir_white.png" width="675" height="100" ></a></div>';

$pdf->writeHTML($html, true, false, true, false, '');

$html = '<p style="text-align:center;font-style:bold;"><b>TAX INVOICE</b><p>
<table  border="1" width="675" cellspacing="4" cellpadding="3">


<tr>
<td  width="120" style="text-align:left">Mr. /Mrs. /Ms.	</td>
<td  width="320" style="text-align:left"><b>'.$cust_name.'</b>	</td>
<td  width="80" style="text-align:left">Bill No </td>
<td  width="120" style="text-align:left"><b>'.$bill_no.'</b></td>
</tr>

<tr >
<td  style="text-align:left">Phone</td>
<td style="text-align:left"><b>'.$cust_phone.'</b></td>
<td style="text-align:left">DATE</td>
<td style="text-align:left"><b>'.$shift_date.'</b></td>
</tr>

<tr>
<td style="text-align:left">Client GST No.	</td>
<td style="text-align:left"><b>'.$client_gst.'</b></td>
<td style="text-align:left">LR. No.</td>
<td style="text-align:left"><b>'.$lr_no.'</b></td>
</tr>

<tr>
<td style="text-align:left">From	</td>
<td style="text-align:left"><b>'.$from_loc.'</b></td>
<td style="text-align:left">To</td>
<td style="text-align:left"><b>'.$to_loc.'</b></td>
</tr>
<tr>
<td  style="text-align:left">Address</td>
<td width="530" style="text-align:left"><b>'.$cust_address.'</b></td>
</tr>


</table>';

$html.='<br><br><table  border="1" width="675" cellspacing="4" cellpadding="3">

<tr>
<td bgcolor="#A8A8A8" width="50">Sr.No	</td>
<td bgcolor="#A8A8A8" width="375" style="text-align:center">PARTICULARS</td>
<td bgcolor="#A8A8A8" style="text-align:left">AMOUNT</td>
</tr>

<tr>
<td >1</td>
<td style="text-align:left"><b>'.$details_1.'</b></td>
<td style="text-align:left"><b>'.$amount_1.'</b></td>

</tr>








<tr>
<td >GSTIN</td>
<td style="text-align:right"> 27AASCS3069G2ZU   <span></span> <span></span>   TOTAL</td>
<td style="text-align:left"><b>'.$amount_1.'</b></td>
</tr>


<tr>
<td></td>
<td style="text-align:right">CGST@ '.$rate_c_gst. ' %</td>
<td style="text-align:left"><b>'.$c_gst.'</b> </td >
</tr>

<tr>
<td>	</td>
<td style="text-align:right">SGST @ '.$rate_s_gst. ' % </td>
<td style="text-align:left"><b>'.$s_gst.'</b> </td >
</tr>

<tr>
<td >	</td>
<td style="text-align:right">SUB TOTAL</td>
<td style="text-align:left"><b>'.$total_amount.'</b></td >
</tr>


</table>';

$html .='<br><br><table   width="650" cellspacing="4" cellpadding="3">

<tr>
<td style="text-align:right"><b>For Shree Mahavir Packers & Movers Pvt. Ltd</b>	</td>
</tr>

<tr>
<td style="text-align:right"><img align=center src="images/circle-stamp-mahavir.png" width="100" height="88" >	</td>
</tr>


<tr>
<td style="text-align:right"><b>Authorised Sign</b></td>
</tr>
<tr>
<td >Thank You !!!</td>
</tr>


<tr>
<td style="text-align:left">Note</td>
</tr>


<tr>
<td style="text-align:left">*Please do not deduct any amount without our consent</td>
</tr>

<tr>
<td style="text-align:left">*All disputes are subject to Mumbai Jurisdiction only</td>
</tr>

<tr>
<td style="text-align:left">*System Generated Invoice.</td>
</tr>

</table>';

$html .='<br><br><br><br><div text-align="center"><a href="https://www.shreemahavirpackers.in" color="#800000" style="text-decoration:none;">© 2020 Shree Mahavir Packers Pvt Ltd Copyright - All Rights Reserved</a></div>';
// output the HTML content
$pdf->writeHTML($html, true, false, true, false, '');

// Print some HTML Cells

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
// Print all HTML colors

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - -


$file_name = preg_replace('/\s+/', '_', $cust_name);
$file_name=$file_name.'_invoice.pdf';


ob_end_clean();

exit($pdf->Output($file_name, 'D'));
//Close and output PDF document
//$pdf->Output('example_006.pdf', 'I');

//============================================================+
// END OF FILE
//============================================================+
