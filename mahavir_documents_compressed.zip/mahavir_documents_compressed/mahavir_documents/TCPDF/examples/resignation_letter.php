<?php
// Include the main TCPDF library (search for installation path).
require_once('tcpdf_include.php');

// create new PDF document
$pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);
$join_date=$_POST['join_date'];
$c_name=$_POST['c_name'];
$designation=$_POST['designation'];
$salary=$_POST['salary'];
$resign_date=$_POST['resign_date'];
$emp_id=$_POST['emp_id'];


header('Content-Type: application/pdf');
header('Content-Disposition: attachment; filename="offer_letter.pdf"');
$pdf->SetHeaderData('logo.png', 10, 'Mahavir Packers Pvt Ltd', PDF_HEADER_STRING);

$pdf->setHeaderFont(Array(PDF_FONT_NAME_MAIN, '', PDF_FONT_SIZE_MAIN));
$pdf->setFooterFont(Array(PDF_FONT_NAME_DATA, '', PDF_FONT_SIZE_DATA));

$pdf->SetDefaultMonospacedFont(PDF_FONT_MONOSPACED);
$pdf->setPrintHeader(false);


//$pdf->SetAutoPageBreak(TRUE, PDF_MARGIN_BOTTOM);

$pdf->setImageScale(PDF_IMAGE_SCALE_RATIO);

// set some language-dependent strings (optional)
if (@file_exists(dirname(__FILE__).'/lang/eng.php')) {
	require_once(dirname(__FILE__).'/lang/eng.php');
	$pdf->setLanguageArray($l);
}

// ---------------------------------------------------------

$pdf->SetFont('dejavusans', '', 10);

$pdf->AddPage();

$html = '<div><a href="https://www.shreemahavirpackers.in"><img align=center src="images/mahavir_white.png" width="675" height="100" ></a></div>';// output the HTML content
$pdf->writeHTML($html, true, false, true, false, '');

$html = '
<table  cellspacing="3" cellpadding="4">
<tr><td style="text-align:right;"><b>'.$resign_date.'</b></td></tr>
<tr><td><b>Emp Name: '.$c_name.', </b></td></tr>
<tr><td><b>Emp Id: '.$emp_id.' </b></td></tr>
<tr><td></td></tr>
<tr><td></td></tr>
<tr><td></td></tr>

<tr><td style="text-align:center;"><b>TO WHOMSOEVER IT MAY CONCERN</b></td></tr>

<tr><td>This is to certify that '.$c_name.' was employed with us from '.$join_date.' to '.$resign_date.' .</td></tr>



<tr><td> At the time of leaving the company he/she was designated as '.$designation.' .</td></tr>


<tr><td>His/Her last drawn salary was Rs. '.$salary.' .</td></tr>

<tr><td>He/She has maintained a good conduct during his work tenure .</td></tr>
<tr><td></td></tr>
<tr><td></td></tr>
<tr><td></td></tr>

<tr><td></td></tr>

<tr><td></td></tr>

<tr><td></td></tr>

<tr><td></td></tr>


<tr>


<td style="text-align:right"><b>For Shree Mahavir Packers & Movers Pvt. Ltd</b>	</td>
</tr>

<tr>
<td style="text-align:right"><img align=center src="images/circle-stamp-mahavir.png" width="100" height="88" >	</td>
</tr>


<tr>
<td style="text-align:right"><b>Authorised Sign</b></td>
</tr>
<tr><td></td></tr>


<tr><td></td></tr>
<tr><td></td></tr>


</table>';

$html .='<br><div align="center"><a href="https://www.shreemahavirpackers.in" color="#800000" style="text-decoration:none;">© 2020 Shree Mahavir Packers Pvt Ltd Copyright - All Rights Reserved</a></div>';
// output the HTML content
$pdf->writeHTML($html, true, false, true, false, '');


$file_name = preg_replace('/\s+/', '_', $c_name);
$file_name=$file_name.'_resignation_letter.pdf';


ob_end_clean();

exit($pdf->Output($file_name, 'D'));

//$pdf->Output('resign_letter.pdf', 'I');
//exit;

//============================================================+
// END OF FILE
//============================================================+
