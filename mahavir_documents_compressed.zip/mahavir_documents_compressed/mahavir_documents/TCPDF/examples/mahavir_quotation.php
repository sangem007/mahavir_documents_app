<?php

require_once('tcpdf_include.php');

$pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);

$cust_name=$_POST['cust_name'];
$cust_phone=$_POST['cust_phone'];
$shift_date=$_POST['shift_date'];
$quotation_no=$_POST['quotation_no'];
$from_loc=$_POST['from_loc'];
$to_loc=$_POST['to_loc'];
$charges_transportation=$_POST['charges_transportation'];
$charges_packing=$_POST['charges_packing'];
$charges_loading=$_POST['charges_loading'];
$charges_unloading=$_POST['charges_unloading'];
$charges_car=$_POST['charges_car'];
$charges_other=$_POST['charges_other'];
$charges_storage=$_POST['charges_storage'];

$rate_insurance=$_POST['rate_insurance'];
$charges_insurance=$_POST['charges_insurance'];
$gst_rate=$_POST['gst_rate'];
$charges_gst=$_POST['charges_gst'];
$total=$_POST['total'];
$items_shift=$_POST['items_shift'];

$sub_total=$_POST['sub_total'];
$exec_name=$_POST['exec_name'];



header('Content-Type: application/pdf');
$f_name = preg_replace('/\s+/', '_', $cust_name);
$f_name=$f_name.'_quotation.pdf';
header('Content-Disposition: attachment; filename='.$f_name.' ');
//$pdf->SetHeaderData('logo.png', 10, 'Mahavir Packers Pvt Ltd', PDF_HEADER_STRING);

$pdf->setHeaderFont(Array(PDF_FONT_NAME_MAIN, '', PDF_FONT_SIZE_MAIN));
$pdf->setFooterFont(Array(PDF_FONT_NAME_DATA, '', PDF_FONT_SIZE_DATA));

$pdf->SetDefaultMonospacedFont(PDF_FONT_MONOSPACED);
$pdf->setPrintHeader(false);


//$pdf->SetAutoPageBreak(TRUE, PDF_MARGIN_BOTTOM);

$pdf->setImageScale(PDF_IMAGE_SCALE_RATIO);

// set some language-dependent strings (optional)
if (@file_exists(dirname(__FILE__).'/lang/eng.php')) {
	require_once(dirname(__FILE__).'/lang/eng.php');
	$pdf->setLanguageArray($l);
}

// ---------------------------------------------------------

$pdf->SetFont('dejavusans', '', 8);

$pdf->AddPage();
$html = '<p></p><p></p><p></p><p></p><p></p><p></p><p></p><p></p><p></p><p></p><p></p><p></p><div align="center"><a href="https://www.shreemahavirpackers.in"><img align=center src="images/new_front.png" width="600" height="420" ></a></div>';
// output the HTML content
$pdf->writeHTML($html, true, false, true, false, '');
$pdf->lastPage();


$pdf->AddPage();

$html = '<div><a href="https://www.shreemahavirpackers.in"><img align=center src="images/mahavir_white.png" width="675" height="100" ></a></div>';

$html .='<table  cellspacing="3" cellpadding="4">

<tr>
<td style="text-align:center;"><b>Quotation</b></td>
</tr>
</table>';
$html .='<table border="1" cellspacing="3" cellpadding="4">

<tr>
<td></td>
<td style="width:295;">Executive Name: <b>'.$exec_name.'</b></td>
<td style="text-align:right;width:100;">Date</td>
<td style="width:100;"><b>'.$shift_date.'</b></td>
</tr>

<tr>
<td></td>
<td style="text-align:right;"> </td>

<td style="text-align:right;">Quotation No.</td>
<td><b>'.$quotation_no.'</b></td>
</tr>

<tr>
<td>To,</td>
<td><b>Mr. /Mrs. /Ms. '.$cust_name.'</b></td>
<td style="text-align:right;">From</td>
<td><b>'.$from_loc.'</b></td>
</tr>


<tr>
<td></td>
<td>Phone Number  <b>'.$cust_phone.'</b></td>
<td style="text-align:right;">To</td>
<td><b>'.$to_loc.'</b></td>
</tr>

<tr>
<td>Dear Sir/Madam,</td>
<td></td>
<td></td>
<td></td>
</tr>

<tr>
<td width="670">As per the our conversation and instructed by your good company, we are hereby sending you the quotation for
shifting of your House Hold Goods Rates are given below:
</td>

</tr>

</table>';

$html .='<br><br><table border="1" cellspacing="3" cellpadding="4">
<tr>
<td width="60">Sr. No.</td>
<td width="500">Particulars</td>
<td width="100">Charges</td>
</tr>

<tr>
<td width="60">1</td>
<td width="500">Transportation charges</td>
<td width="100"><b>'.$charges_transportation.'</b></td>
</tr>

<tr>
<td width="60">2</td>
<td width="500">Packing Charges using quality packing materials</td>
<td width="100"><b>'.$charges_packing.'</b></td>
</tr>

<tr>
<td width="60">3</td>
<td width="500">Loading Charges </td>
<td width="100"><b>'.$charges_loading.'</b></td>
</tr>


<tr>
<td width="60">4</td>
<td width="500">Unloading Charges</td>
<td width="100"><b>'.$charges_unloading.'</b></td>
</tr>
<tr>
<td width="60">5</td>
<td width="500">Car Transportation Door to Door</td>
<td width="100"><b>'.$charges_car.'</b></td>
</tr>

<tr>
<td width="60">6</td>
<td width="500">Other Charges</td>
<td width="100"><b>'.$charges_other.'</b></td>
</tr>

<tr>
<td width="60">7</td>
<td width="500">Storage Charges </td>
<td width="100"><b>'.$charges_storage.'</b></td>
</tr>

<tr>
<td width="60"></td>
<td width="500">SUB TOTAL</td>
<td width="100"><b>'.$sub_total.'</b></td>
</tr>

<tr>
<td width="60"></td>
<td width="500">Insurance charge on declare value by you @  <b>'.$rate_insurance.'</b> % on declared value </td>
<td width="100"><b>'.$charges_insurance.'</b></td>
</tr>

<tr>
<td width="60"></td>
<td width="500">GST @ <b>'.$gst_rate.'</b> %</td>
<td width="100"><b>'.$charges_gst.'</b></td>
</tr>



<tr>
<td width="60"></td>
<td width="500">TOTAL</td>
<td width="100"><b>'.$total.'</b></td>
</tr>
</table>';

$html .='<br><br><table  cellspacing="3" cellpadding="4">
<tr><td><b>Items to Shift</b></td></tr>
<tr><td color="RED"><b>'.$items_shift.'</b></td></tr>
</table>';


$html .='<br><br><table  cellspacing="3" cellpadding="4">
<tr><td>Terms & Conditions</td></tr>
<tr><td>1 .Packaging will be based on the pre-discussed terms. Mathadi Union Charges By Party ,</td></tr>
<tr><td>2 .100% payment for part-load service and 80% for full-load services,let us know society timings,rules and lift timings in advance</td></tr>
<tr><td>3 .We request you to give us 2 days advance notice via whatsapp or email, to give you a prompt service.</td></tr>
</table>';

$html .='<br><table   width="675" cellspacing="4" cellpadding="3">

<tr>
<td style="text-align:right"><b>For Shree Mahavir Packers & Movers Pvt. Ltd</b>	</td>
</tr>
<tr>
<td style="text-align:right"><img align=center src="images/circle-stamp-mahavir.png" width="100" height="88" >	</td>
</tr>
<tr>
<td style="text-align:right"><b>Authorised Sign</b></td>
</tr>
<tr>
<td style="text-align:center"><b>Thank You !!!</b></td>
</tr>
</table>';

$pdf->writeHTML($html, true, false, true, false, '');
$pdf->lastPage();


$pdf->AddPage();
$html = '<div><a href="https://www.shreemahavirpackers.in"><img align=center src="images/mahavir_white.png" width="675" height="100" ></a></div>';

$html .='<br><table   width="675" cellspacing="4" cellpadding="3">

<tr>
<td>To,</td>
</tr>
<tr>
<td>Mr./Mrs /Ms <b> '.$cust_name.'</b></td>
</tr>

<tr>
<td>Dear Sir /Madam,</td>
</tr>

<tr>
<td>  We would like to inform you that we are of <b>Shree Mahavir Packers & Movers Pvt. Ltd. </b> we are going to take Total
Transportation activity of our one of the Client. This has with reference to your discussion with the undersigned
the Packing & Moving of your consignments,
We thank you for your enquiry, as at the very outset and would like to extend our gratitude for the confidence
response in considering us for your service needs.We at Shree Mahavir Packers & Movers Pvt. Ltd. fully
understand the needs for Express Distribution and, We offer services by Surface, Air,and multi Model connection.

Each of our trucks contain these neoprene runners. These runners protect your carpet and wood floors from dirt &
grime. We know that quality floor protection is an essential part of a successful move. we shrink wrap your
furniture before moving it.
We use stretch wrap to protect and secure loose drawers and glass. We can use stretch wrap for just about any shape
of furniture. We use this great stuff on every move and we wonder how the other guys move without it. It is great for
antiques. we use only clean high quality moving blankets and pads.
We require each piece of furniture and anything subject to damage be padded. In addition, we pad your
stair railings, doors and door jambs to prevent accidental damage to your home or office.

<b>Shree Mahavir Packers & Movers Pvt. Ltd.</b> moving hand truck and dollies for our
Having the right tools for the job is always the right way to go when you are moving. Our dollies and
hand trucks all have fully padded back frames to protect your furniture and skid bar glides to protect your
stairs. These are vital tools to ensure an efficient, damage free move.
</td>
</tr>


</table>';

$html .='<br><br><br><table   width="675" cellspacing="4" cellpadding="3">

<tr>
<td>OUR SERVICES </td>
<td></td>
<td></td>
</tr>

<tr>
<td>=> <b>Packing and Moving</b> </td>
<td>=> <b>Home Shifting</b></td>
<td>=> <b>Office Shifting</b> </td>
</tr>


<tr>
<td>=> <b>Loading </b></td>
<td>=> <b>Unloading </b></td>
<td>=> <b>Car Transportation</b> </td>
</tr>


<tr>
<td>=> <b>Insurance </b></td>
<td>=> <b>Local Shifting </b></td>
<td>=> <b>Warehousing </b></td>
</tr>



</table><p></p><p></p><p></p><p></p><p></p><p></p><p><b>Assuring you of our best service & looking forward to have a pleasure of long term business relationship.
</p></b>';

$html .='<br><p></p><p></p><p></p><p></p><p></p><p></p><p></p><p></p><p></p><p></p><p></p><p></p><p></p><p></p><p></p><p></p><p></p><p></p><p></p><p></p><p></p><div align="center"><a href="https://www.shreemahavirpackers.in" color="#800000" style="text-decoration:none;">© 2020 Shree Mahavir Packers Pvt Ltd Copyright - All Rights Reserved</a></div>';


// output the HTML content
$pdf->writeHTML($html, true, false, true, false, '');

$pdf->lastPage();



// - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
// Print a table

// add a page
$pdf->AddPage();
$html = '<div><a href="https://www.shreemahavirpackers.in"><img align=center src="images/mahavir_white.png" width="675" height="100" ></a></div>
</div><p style="text-align:center;"><b>ABOUT US</b></p>';

$html .='<p>We at Shree Mahavir Packers and Movers Pvt Ltd. in mumbai a most adored shifting services in mumbai.Contact us on 7666866602 / 02229666999 . We give dependable shifting solutions, transportation services, warehousing, corporate shifting, Household relocation, etc. We are only one call away and constantly quick to help our customers for their simple and smooth moving experience. We are the one stop packers and movers  to provide affordable and reliable packing and moving solutions

You may be thinking to relocate and eagerly looking for solid packers and movers  to shift with no hassle. Do plan your requirements, before contracting any Relocation and moving firm. What is generally essential to know is the thing that what they offer and what they cost for it. By knowing the expense and charges of packers and movers you can design your spending limit and furthermore it helps in picking the correct packers and movers for you. 

Since decades, we are catering our services to individuals, families and business units. The best part is that our firm extends our services at national levels for any kind of requirements. Whether it’s a complete, part and return loads, we offer this with exceptional consistency and considerable regards towards timeliness. Our services are reflected by three words Trust, Pioneering and Branding. With the help of wide distribution of network, we are able to cater our services in every hook and corner of the country. Since decades, we are giving importance to customer’s delight.
 
Shree Mahavir Packers & Movers’ Pvt Ltd. expertise lies in packing and moving anything from household removals to heavy demanding large scale corporate removals. Our teammates are competent enough to pack precious assets like a fridge, washing machine, range of furniture, gadgets and even vehicles of all sizes.
 
Our area of expertise also lies in Corporate Relocation. We are the preferred choice as we impart safe and secure movements by land, air or sea. So, if you are looking to relocate your home or corporate office then we are just few steps away from you.
 
For the apt services, our representative will take a stock of things and provide you with an estimate. After the approval, we would spring into action and schedule a date to finalize packing and delivering.</p>';


$html .='<p><b> We offer following services </b></p>
<p> => One Client- One Executive.</p>
<p> => E-Dedicated Telephone Lines, Online Facilities.</p>
<p> => 24 Hrs. Security – Well Guarded Premises.</p>
<p> => Express Distribution & Packing, unpacking System.</p>
<p> => Warehousing & Car Transportation.</p>
<p> => Air, Road, & Train, Services. </p>
<p> => Supplier-Truck, Tempo, Tailor, All India.</p>
<p> => Packing and Moving of Office Furniture & Household Goods,IT Goods and industrial Goods.</p>
<p> => Time Bound Delivery.</p>
<p> => Insurance and Storage</p>


';
$html .='<br><p></p><p></p><p></p><p></p><p></p><p></p><p></p><p></p><p></p><p></p><p></p><p></p><p></p><p></p><p></p><p></p><div align="center"><a href="https://www.shreemahavirpackers.in" color="#800000" style="text-decoration:none;">© 2020 Shree Mahavir Packers Pvt Ltd Copyright - All Rights Reserved</a></div>';

$pdf->writeHTML($html, true, false, true, false, '');

$pdf->lastPage();


$pdf->AddPage();
//$pdf->Ln(60);


$html = '<div><a href="https://www.shreemahavirpackers.in"><img align=center src="images/mahavir_white.png" width="675" height="100" ></a></div>';


//$pdf->Ln(100);
$html .='<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><table   width="675" cellspacing="4" cellpadding="3">




<tr>
<td><a href="https://www.shreemahavirpackers.in"><img src="images/image_1.jpg" width="150" height="150"></a></td>
<td><a href="https://www.shreemahavirpackers.in"><img src="images/image_2.jpg" width="150" height="150"></a></td>
<td><a href="https://www.shreemahavirpackers.in"><img src="images/image_3.jpg" width="150" height="150"></a></td>
<td><a href="https://www.shreemahavirpackers.in"><img src="images/image_4.jpg" width="150" height="150"></a></td>
</tr>

<tr>
<td><a href="https://www.shreemahavirpackers.in"><img src="images/image_5.jpg" width="150" height="150"></a></td>
<td><a href="https://www.shreemahavirpackers.in"><img src="images/image_6.jpg" width="150" height="150"></a></td>
<td><a href="https://www.shreemahavirpackers.in"><img src="images/image_7.jpg" width="150" height="150"></a></td>
<td><a href="https://www.shreemahavirpackers.in"><img src="images/image_8.jpg" width="150" height="150"></a></td>
</tr>




</table>';

$html .='<p style="text-align:center;"><b>Our Branches</b></p><table   width="675" cellspacing="4" cellpadding="3"> 
<tr>
<td>Packers & Movers Ahmedabad</td>
<td>Packers & Movers Baroda</td>
<td>Packers & Movers Jaipur</td>
</tr>

<tr>
<td>Packers & Movers Udaipur</td>
<td>Packers & Movers Delhi</td>
<td>Packers & Movers Hyderabad</td>
</tr>

<tr>
<td>Packers & Movers Chennai</td>
<td>Packers & Movers Bangalore</td>
<td>Packers & Movers Indore</td>
</tr>

<tr>
<td>Packers & Movers Bhopal</td>
<td>Packers & Movers Pune</td>
<td>Packers & Movers Nagpur</td>
</tr>

<tr>
<td>Packers & Movers Agra</td>
<td>Packers & Movers Madhurai</td>
<td>Packers & Movers Kota</td>
</tr>

<tr>
<td>Packers & Movers Chandigarh</td>
<td>Packers & Movers Panaji</td>
<td></td>
</tr>


</table>';



$html .='<br><div align="center"><a href="https://www.shreemahavirpackers.in" color="#800000" style="text-decoration:none;">© 2020 Shree Mahavir Packers Pvt Ltd Copyright - All Rights Reserved</a></div>';


// output the HTML content
$pdf->writeHTML($html, true, false, true, false, '');

$pdf->lastPage();




ob_end_clean();

exit($pdf->Output($f_name, 'D'));
