<?php


// Include the main TCPDF library (search for installation path).
require_once('tcpdf_include.php');

// create new PDF document
$pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);

$cust_name=$_POST['cust_name'];
$shift_date=$_POST['shift_date'];
$lr_no=$_POST['lr_no'];
$from_loc=$_POST['from_loc'];
$to_loc=$_POST['to_loc'];
$exec_name=$_POST['exec_name'];

$desc_1=$_POST['desc_1'];
$desc_2=$_POST['desc_2'];
$desc_3=$_POST['desc_3'];
$desc_4=$_POST['desc_4'];
$desc_5=$_POST['desc_5'];
$desc_6=$_POST['desc_6'];
$desc_7=$_POST['desc_7'];
$desc_8=$_POST['desc_8'];
$desc_9=$_POST['desc_9'];
$desc_10=$_POST['desc_10'];
$desc_11=$_POST['desc_11'];
$desc_12=$_POST['desc_12'];
$desc_13=$_POST['desc_13'];
$desc_14=$_POST['desc_14'];
$desc_15=$_POST['desc_15'];
$desc_16=$_POST['desc_16'];
$desc_17=$_POST['desc_17'];
$desc_18=$_POST['desc_18'];
$desc_19=$_POST['desc_19'];
$desc_20=$_POST['desc_20'];
$desc_21=$_POST['desc_21'];
$desc_22=$_POST['desc_22'];
$desc_23=$_POST['desc_23'];
$desc_24=$_POST['desc_24'];
$desc_25=$_POST['desc_25'];
$desc_26=$_POST['desc_26'];
$desc_27=$_POST['desc_27'];
$desc_28=$_POST['desc_28'];
$desc_29=$_POST['desc_29'];
$desc_30=$_POST['desc_30'];







$pack_1=$_POST['pack_1'];
$pack_2=$_POST['pack_2'];
$pack_3=$_POST['pack_3'];
$pack_4=$_POST['pack_4'];
$pack_5=$_POST['pack_5'];
$pack_6=$_POST['pack_6'];
$pack_7=$_POST['pack_7'];
$pack_8=$_POST['pack_8'];
$pack_9=$_POST['pack_9'];
$pack_10=$_POST['pack_10'];
$pack_11=$_POST['pack_11'];
$pack_12=$_POST['pack_12'];
$pack_13=$_POST['pack_13'];
$pack_14=$_POST['pack_14'];
$pack_15=$_POST['pack_15'];
$pack_16=$_POST['pack_16'];
$pack_17=$_POST['pack_17'];
$pack_18=$_POST['pack_18'];
$pack_19=$_POST['pack_19'];
$pack_20=$_POST['pack_20'];
$pack_21=$_POST['pack_21'];
$pack_22=$_POST['pack_22'];
$pack_23=$_POST['pack_23'];
$pack_24=$_POST['pack_24'];
$pack_25=$_POST['pack_25'];
$pack_26=$_POST['pack_26'];
$pack_27=$_POST['pack_27'];
$pack_28=$_POST['pack_28'];
$pack_29=$_POST['pack_29'];
$pack_30=$_POST['pack_30'];








$volume_1=$_POST['volume_1'];
$volume_2=$_POST['volume_2'];
$volume_3=$_POST['volume_3'];
$volume_4=$_POST['volume_4'];
$volume_5=$_POST['volume_5'];
$volume_6=$_POST['volume_6'];
$volume_7=$_POST['volume_7'];
$volume_8=$_POST['volume_8'];
$volume_9=$_POST['volume_9'];
$volume_10=$_POST['volume_10'];
$volume_11=$_POST['volume_11'];
$volume_12=$_POST['volume_12'];
$volume_13=$_POST['volume_13'];
$volume_14=$_POST['volume_14'];
$volume_15=$_POST['volume_15'];
$volume_16=$_POST['volume_16'];
$volume_17=$_POST['volume_17'];
$volume_18=$_POST['volume_18'];
$volume_19=$_POST['volume_19'];
$volume_20=$_POST['volume_20'];
$volume_21=$_POST['volume_21'];
$volume_22=$_POST['volume_22'];
$volume_23=$_POST['volume_23'];
$volume_24=$_POST['volume_24'];
$volume_25=$_POST['volume_25'];
$volume_26=$_POST['volume_26'];
$volume_27=$_POST['volume_27'];
$volume_28=$_POST['volume_28'];
$volume_29=$_POST['volume_28'];
$volume_30=$_POST['volume_30'];


















/*
// set document information
$pdf->SetCreator('Mahavir Packers');
$pdf->SetAuthor('Mahavir Packers Pvt Ltd');
$pdf->SetTitle('Article List');
$pdf->SetSubject('Article List');
$pdf->SetKeywords('TCPDF, PDF, example, test, guide');

*/

header('Content-Type: application/pdf');
header('Content-Disposition: attachment; filename="article_list.pdf"');
$pdf->SetHeaderData('logo.png', 10, 'Mahavir Packers Pvt Ltd', PDF_HEADER_STRING);

$pdf->setHeaderFont(Array(PDF_FONT_NAME_MAIN, '', PDF_FONT_SIZE_MAIN));
$pdf->setFooterFont(Array(PDF_FONT_NAME_DATA, '', PDF_FONT_SIZE_DATA));

$pdf->SetDefaultMonospacedFont(PDF_FONT_MONOSPACED);
$pdf->setPrintHeader(false);


//$pdf->SetAutoPageBreak(TRUE, PDF_MARGIN_BOTTOM);

$pdf->setImageScale(PDF_IMAGE_SCALE_RATIO);

// set some language-dependent strings (optional)
if (@file_exists(dirname(__FILE__).'/lang/eng.php')) {
	require_once(dirname(__FILE__).'/lang/eng.php');
	$pdf->setLanguageArray($l);
}

// ---------------------------------------------------------

$pdf->SetFont('dejavusans', '', 10);

$pdf->AddPage();

$html = '<div><a href="https://www.shreemahavirpackers.in"><img align=center src="images/mahavir_white.png" width="675" height="100" ></a></div>';// output the HTML content
$pdf->writeHTML($html, true, false, true, false, '');


// output some RTL HTML content


// test some inline CSS

// reset pointer to the last page
//$pdf->lastPage();

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
// Print a table

// add a page
//$pdf->AddPage();

// create some HTML content

$row='<tr>
<td align="right"></td>
<td ></td>
<td></td>
<td></td>
</tr>';



$html = '
<table border="1" cellspacing="3" cellpadding="4">

	<tr>
<td>Mr. Mrs. Ms.</td>
<td border="none" colspan="3"><b>'.$cust_name.'</b></td>
</tr>

<tr>
<td align="right" colspan="3">Date</td>
<td ><b>'.$shift_date.'</b></td>
</tr>

<tr>
<td align="left" >LR No.</td>
<td ><b>'.$lr_no.'</b></td>
<td align="right" >From</td>
<td ><b>'.$from_loc.'</b></td>
</tr>
<tr>
<td align="right" colspan="3">To</td>
<td ><b>'.$to_loc.'</b></td>
</tr>

<tr>
<td bgcolor="#A8A8A8" width="50" align="right">Sr No.</td>
<td bgcolor="#A8A8A8" width="280">Description of goods</td>
<td bgcolor="#A8A8A8">Packing</td>
<td bgcolor="#A8A8A8">Volume</td>
</tr>

<tr>
<td align="right">1</td>
<td ><b>'.$desc_1.'</b></td>
<td><b>'.$pack_1.'</b></td>
<td><b>'.$volume_1.'</b></td>
</tr>

<tr>
<td align="right">2</td>
<td ><b>'.$desc_2.'</b></td>
<td><b>'.$pack_2.'</b></td>
<td><b>'.$volume_2.'</b></td>
</tr>


<tr>
<td align="right">3</td>
<td >'.$desc_3.'</td>
<td>'.$pack_3.'</td>
<td>'.$volume_3.'</td>
</tr>



<tr>
<td align="right">4</td>
<td >'.$desc_4.'</td>
<td>'.$pack_4.'</td>
<td>'.$volume_4.'</td>

</tr>





<tr>
<td align="right">5</td>
<td >'.$desc_5.'</td>
<td>'.$pack_5.'</td>
<td>'.$volume_5.'</td>

</tr>


<tr>
<td align="right">6</td>
<td >'.$desc_6.'</td>
<td>'.$pack_6.'</td>
<td>'.$volume_6.'</td>

</tr>




<tr>
<td align="right">7</td>
<td >'.$desc_7.'</td>
<td>'.$pack_7.'</td>
<td>'.$volume_7.'</td>

</tr>



<tr>
<td align="right">8</td>
<td >'.$desc_8.'</td>
<td>'.$pack_8.'</td>
<td>'.$volume_8.'</td>

</tr>


<tr>
<td align="right">9</td>
<td >'.$desc_9.'</td>
<td>'.$pack_9.'</td>
<td>'.$volume_9.'</td>

</tr>


<tr>
<td align="right">10</td>
<td >'.$desc_10.'</td>
<td>'.$pack_10.'</td>
<td>'.$volume_10.'</td>

</tr>


<tr>
<td align="right">11</td>
<td >'.$desc_11.'</td>
<td>'.$pack_11.'</td>
<td>'.$volume_11.'</td>

</tr>


<tr>
<td align="right">12</td>
<td >'.$desc_12.'</td>
<td>'.$pack_12.'</td>
<td>'.$volume_12.'</td>

</tr>

<tr>
<td align="right">13</td>
<td >'.$desc_13.'</td>
<td>'.$pack_13.'</td>
<td>'.$volume_13.'</td>

</tr>



<tr>
<td align="right">14</td>
<td >'.$desc_14.'</td>
<td>'.$pack_14.'</td>
<td>'.$volume_14.'</td>

</tr>


<tr>
<td align="right">15</td>
<td >'.$desc_15.'</td>
<td>'.$pack_15.'</td>
<td>'.$volume_15.'</td>

</tr>

<tr>
<td align="right">16</td>
<td >'.$desc_16.'</td>
<td>'.$pack_16.'</td>
<td>'.$volume_16.'</td>

</tr>

<tr>
<td align="right">17</td>
<td >'.$desc_17.'</td>
<td>'.$pack_17.'</td>
<td>'.$volume_17.'</td>

</tr>

<tr>
<td align="right">18</td>
<td >'.$desc_18.'</td>
<td>'.$pack_18.'</td>
<td>'.$volume_18.'</td>

</tr>

<tr>
<td align="right">19</td>
<td >'.$desc_19.'</td>
<td>'.$pack_19.'</td>
<td>'.$volume_19.'</td>

</tr>

<tr>
<td align="right">20</td>
<td >'.$desc_20.'</td>
<td>'.$pack_20.'</td>
<td>'.$volume_20.'</td>

</tr>

<tr>
<td align="right">21</td>
<td >'.$desc_21.'</td>
<td>'.$pack_21.'</td>
<td>'.$volume_21.'</td>

</tr>

<tr>
<td align="right">22</td>
<td >'.$desc_22.'</td>
<td>'.$pack_22.'</td>
<td>'.$volume_22.'</td>

</tr>

<tr>
<td align="right">23</td>
<td >'.$desc_23.'</td>
<td>'.$pack_23.'</td>
<td>'.$volume_23.'</td>

</tr>


<tr>
<td align="right">24</td>
<td >'.$desc_24.'</td>
<td>'.$pack_24.'</td>
<td>'.$volume_24.'</td>

</tr>


<tr>
<td align="right">25</td>
<td >'.$desc_25.'</td>
<td>'.$pack_25.'</td>
<td>'.$volume_25.'</td>

</tr>


<tr>
<td align="right">26</td>
<td >'.$desc_26.'</td>
<td>'.$pack_26.'</td>
<td>'.$volume_26.'</td>

</tr>

<tr>
<td align="right">27</td>
<td >'.$desc_27.'</td>
<td>'.$pack_27.'</td>
<td>'.$volume_27.'</td>

</tr>


<tr>
<td align="right">28</td>
<td >'.$desc_28.'</td>
<td>'.$pack_28.'</td>
<td>'.$volume_28.'</td>

</tr>

<tr>
<td align="right">29</td>
<td >'.$desc_29.'</td>
<td>'.$pack_29.'</td>
<td>'.$volume_29.'</td>

</tr>


<tr>
<td align="right">30</td>
<td >'.$desc_30.'</td>
<td>'.$pack_30.'</td>
<td>'.$volume_30.'</td>

</tr>


<tr>
<td width="150" align="right">Executive Name</td>
<td width="180">'.$exec_name.'</td>
<td width="155">Customer Sign</td>
<td width="175"></td>
</tr>
</table>';

$html .='<br><div align="center"><a href="https://www.shreemahavirpackers.in" color="#800000" style="text-decoration:none;">© 2020 Shree Mahavir Packers Pvt Ltd Copyright - All Rights Reserved</a></div>';
// output the HTML content
$pdf->writeHTML($html, true, false, true, false, '');

// Print some HTML Cells

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
// Print all HTML colors

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

// test custom bullet points for list


// ---------------------------------------------------------

$file_name = preg_replace('/\s+/', '_', $cust_name);
$file_name=$file_name.'_article_list.pdf';


ob_end_clean();

exit($pdf->Output($file_name, 'D'));

//$pdf->Output('example_006.pdf', 'I');
//exit;

//============================================================+
// END OF FILE
//============================================================+
