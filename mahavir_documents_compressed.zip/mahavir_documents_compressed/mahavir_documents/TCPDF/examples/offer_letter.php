<?php
// Include the main TCPDF library (search for installation path).
require_once('tcpdf_include.php');

// create new PDF document
$pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);
$join_date=$_POST['join_date'];
$c_name=$_POST['c_name'];
$designation=$_POST['designation'];
$salary=$_POST['salary'];

header('Content-Type: application/pdf');
header('Content-Disposition: attachment; filename="offer_letter.pdf"');
$pdf->SetHeaderData('logo.png', 10, 'Mahavir Packers Pvt Ltd', PDF_HEADER_STRING);

$pdf->setHeaderFont(Array(PDF_FONT_NAME_MAIN, '', PDF_FONT_SIZE_MAIN));
$pdf->setFooterFont(Array(PDF_FONT_NAME_DATA, '', PDF_FONT_SIZE_DATA));

$pdf->SetDefaultMonospacedFont(PDF_FONT_MONOSPACED);
$pdf->setPrintHeader(false);


//$pdf->SetAutoPageBreak(TRUE, PDF_MARGIN_BOTTOM);

$pdf->setImageScale(PDF_IMAGE_SCALE_RATIO);

// set some language-dependent strings (optional)
if (@file_exists(dirname(__FILE__).'/lang/eng.php')) {
	require_once(dirname(__FILE__).'/lang/eng.php');
	$pdf->setLanguageArray($l);
}

// ---------------------------------------------------------

$pdf->SetFont('dejavusans', '', 10);

$pdf->AddPage();

$html = '<div><a href="https://www.shreemahavirpackers.in"><img align=center src="images/mahavir_white.png" width="675" height="100" ></a></div>';// output the HTML content
$pdf->writeHTML($html, true, false, true, false, '');

$html = '
<table  cellspacing="3" cellpadding="4">
<tr><td style="text-align:right;"><b>'.$join_date.'</b></td></tr>
<tr><td style="text-align:center;"><b>LETTER OF OFFER </b></td></tr>
<tr><td><b>Dear '.$c_name.', </b></td></tr>

<tr><td>This has reference to your application and the subsequent interview you had with us. We are pleased to offer you
appointment in our organization effective from <b>'.$join_date.' </b>as <b>'.$designation.'</b>, for our Mumbai
Office on the following terms & conditions: </td></tr>



<tr><td> => This Offer is valid on or before the aforementioned joining date and subject to the submission of the accepted
signed copy of the resignation and relieving letter from your present employer within 3 working days from
the date of receipt of this letter.</td></tr>


<tr><td> => You will be paid <b>'.$salary.'</b> Per month Cost to Company
basis as per Annexure – I enclosed herewith. All payments are subject to deductions as the provisions under
various State Government and Central Government enactments .</td></tr>

<tr><td> => You will be bound by the Terms & Conditions of the Employment Agreement, Company Policy and Rules
Regulations, Standing Orders in force and framed by the company from time to time in relation to your
service condition, which will from part of your terms of employment .</td></tr>

<tr><td> => Your appointment is being made on the basis of your particulars such as qualifications etc. as given by you in
your application for employment and in case any information as given by you is found false or incorrect, your
appointment will be deemed void and liable for termination without any notice or salary in lieu of notice.</td></tr>

<tr><td> => We do not believe in the concept of paying bonuses on a particular occasion or festivities (including Diwali).We distribute only sweets to All of our employees during Diwali.
</td></tr>

<tr><td> => Your employment by the Company is conditional upon and subject to the completion of a background check,
and approval thereof by the Company, in its sole discretion. </td></tr>

<tr><td style="text-align:center">We congratulate you on your employment with us and wish you a long and successful career with us. </td></tr>
<tr><td></td></tr>
<tr><td></td></tr>
<tr>


<td style="text-align:right"><b>For Shree Mahavir Packers & Movers Pvt. Ltd</b>	</td>
</tr>

<tr>
<td style="text-align:right"><img align=center src="images/circle-stamp-mahavir.png" width="100" height="88" >	</td>
</tr>


<tr>
<td style="text-align:right"><b>Authorised Sign</b></td>
</tr>
<tr><td></td></tr>

<tr><td style="text-align:center">I accept the terms and condition of offer letter in totality.  </td></tr>

<tr><td></td></tr>
<tr><td></td></tr>

<tr><td>Name: '.$c_name.' </td></tr>

</table>';

$html .='<br><div align="center"><a href="https://www.shreemahavirpackers.in" color="#800000" style="text-decoration:none;">© 2020 Shree Mahavir Packers Pvt Ltd Copyright - All Rights Reserved</a></div>';
// output the HTML content
$pdf->writeHTML($html, true, false, true, false, '');
$pdf->lastPage();


$pdf->AddPage();
//$pdf->Ln(60);


$html = '<div><a href="https://www.shreemahavirpackers.in"><img align=center src="images/mahavir_white.png" width="675" height="100" ></a></div>';// output the HTML content

$html .= '
<table  cellspacing="3" cellpadding="4">
<tr><td><b>As a part of the joining process, please send the scan copy of below documents ASAP: </b></td></tr>
<tr><td><b>Personal Data: </b></td></tr>
<tr><td> => Resume</td></tr>
<tr><td> => Passport</td></tr>
<tr><td> => PAN card- In case of non-availability of PAN, photocopy of application. </td></tr>
<tr><td> => ID Proof - Voter ID Card / Adhaar Card / Any Other Govt Approved ID Proof </td></tr>
<tr><td> => Address Proof - Rent agreement copy / Electricity Bill / Ration Card / Telephone Bill etc. (Except driver’s
license) </td></tr>

<tr><td> => Mark Sheets and Certificate of X, XII, Final year, latest qualification. </td></tr>
<tr><td> => Mark sheets for all semesters during Graduation & Post Graduation </td></tr>
<tr><td> => Mark sheets and Certificates of Diploma(s) </td></tr>
<tr><td> => Mark sheets and Certificates of any training(s) attended</td></tr>
<tr><td> => Any other additional diplomas/certificates (Mark-sheets)</td></tr>
<tr><td> => 5 Photographs (Passport size) </td></tr>
<tr><td> => Personal Bank cheque and Bank Statement (HDFC OR Non- HDFC) </td></tr>


<tr><td><b>Previous Employment Record:  </b></td></tr>
<tr><td> => Offer / Appointment / Confirmation Letter from all previous employer(s)</td></tr>
<tr><td> => Appraisal Letter from all previous employer(s) </td></tr>
<tr><td> => Relieving Letter and Work Experience Certificate from all previous employer(s)</td></tr>
<tr><td> => Copy of the resignation letter of your previous employer(s) </td></tr>
<tr><td> => Salary slips / certificate / bank statement (Last 3 months) from the last employer</td></tr>

</table>';

$html .='<br><div align="center"><a href="https://www.shreemahavirpackers.in" color="#800000" style="text-decoration:none;">© 2020 Shree Mahavir Packers Pvt Ltd Copyright - All Rights Reserved</a></div>';


// output the HTML content
$pdf->writeHTML($html, true, false, true, false, '');

$pdf->lastPage();
$file_name = preg_replace('/\s+/', '_', $c_name);
$file_name=$file_name.'_offer_letter.pdf';


ob_end_clean();

exit($pdf->Output($file_name, 'D'));

//$pdf->Output('offer_letter.pdf', 'I');
//exit;

//============================================================+
// END OF FILE
//============================================================+
